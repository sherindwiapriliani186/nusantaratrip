<body>	
<div class="wrapper">

	<div class="header">
			
			<div class="logo">
				<img src="img/voli.png" />
			</div>
			
			<div class="title">
				Berita Bola Voli
			</div>
			<div class="dark-mode">
				<input type="checkbox" id="toggle" name="toggle">
				<label for="toggle"></label>
			</div>
			
		</div>
		<div class="profil">
				<ul>
					<a href="profil.html"> <li>Profile</li> </a>
				</ul>
				</div>
				
				<div class="profil">
				<ul>
					<a href="list.html"> <li>List APP</li> </a>
				</ul>
			</div>
</body>
</div>
