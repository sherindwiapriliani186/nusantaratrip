<body>
<div class="wrapper">
<div class="right-side">
<!-- yang dikanan -->
					<div class="search">
						<img src="img/carii.jpg"/>
						<div class="search-title">
							Cari
						</div>
					</div>
					
					<div class="right1">
				
						<div class="right1-title">
							Proliga 2021 resmi tidak diselenggarakan
						</div>
					</div>
					
					<div class="right1">
						
						<div class="right1-title">
							Proliga tidak digelar karena tidak ada sponsor
						</div>
					</div>
					
					<div class="right1">
						
						<div class="right1-title">
							Tangis serba Aprillia Manganang setelah permohonan menjadi pria di kabulkan hakim
						</div>
					</div>
				</div>
</body>