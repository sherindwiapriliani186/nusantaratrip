<body>
<div class="wrapper">
	<div class="content">
<!-- yang dikiri			 -->
				<div class="left-side">
					<div class="gs">
						<div class="gs-title">
							Berita Terkini
						</div>
					</div>
					
					<div class="gj">
						<img src="img/pager.png" />
						<div class="gj-title">
							<a href="pp pbvsi.html">pp pbvsi</div>
					</div>
					
					<div class="gj">
						<img src="img/pager.png" />
						<div class="gj-title">
							<a href="proliga 2021.html">proliga 2021</div>
					</div>
					
					<div class="gj">
						<img src="img/pager.png" />
						<div class="gj-title">
							<a href="sea games.html">sea games</div>
					</div>
				</div>
	</div>
</body>