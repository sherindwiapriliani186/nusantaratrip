<body>
<div class="wrapper">
<div class="menu">
<!-- yang ditengah -->
					<div class="md1">
						<img src="img/Apr.png"/>
						<div class="md1-title">
							<a href="pp pbvsi.html">Proliga 2021 resmi tidak diselenggarakan</a>
							<p>Pada 29 Mar 2021, 21:35 WIB</p>
							<p>Bogi Triyadi</p>
						</div>
					</div>
					
					<div class="md1">
						<img src="img/SBY.png" />
						<div class="md1-title">
							<a href="proliga 2021.html">Proliga tidak ada, klub SBY lavani gelar turnamen<a>
							<p>Pada 30 Mar 2021, 14:30 WIB</p>
							<p>Bogi Triyadi</p>
						</div>
					</div>
					
					<div class="md1">
						<img src="img/randu.png"/>
						<div class="md1-title">
							<a href="sea games.html">Proliga tidak digelar karena tak ada sponsor, ini</a>
							<p>Pada 30 Mar 2021</p>
							<p>Bogi Triyadi</>
						</div>
					</div>
					

				</div>
</body>