<body>	
<div class="wrapper">
	<div class="footer">
					<marquee>NANANG QOSIM FOOTER</marquee>
				</div>
	</div>
</body>